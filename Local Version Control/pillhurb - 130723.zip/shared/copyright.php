<?php
	echo "Copyright &copy " . date('Y') . " TEGN300 Investments";
	echo "<span class='float-end'>Version 1.0</span>";
?>