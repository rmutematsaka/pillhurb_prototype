<?php
	$servername = "localhost";
	$user = "root";
	$password = "wuapkn";
	$dbname = "pillhub";
	// Create connection
	$conn = new mysqli($servername, $user, $password, $dbname);
?>