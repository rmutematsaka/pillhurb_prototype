<?php
	SESSION_START();
	SESSION_DESTROY();
	header('location: index.php');
?>